# TS-Ready
It is an initial TypeScript installation. Ready for use.

## Installation
```
npm install
```